package com.tinoprojects.weatherforecastapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherForecastAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
